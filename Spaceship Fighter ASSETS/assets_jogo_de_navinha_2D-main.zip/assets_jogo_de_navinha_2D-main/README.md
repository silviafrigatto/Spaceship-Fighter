# assets_jogo_de_navinha_2D
Esse repositório contém os arquivos utilizando no Curso "Crie um Jogo de Navinha 2D na Unity", do canal Desenvolvendo Jogos!
